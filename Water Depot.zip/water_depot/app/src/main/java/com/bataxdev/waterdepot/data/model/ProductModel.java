package com.bataxdev.waterdepot.data.model;

import android.net.Uri;

public class ProductModel {

    private String name;
    private double harga;
    private String keterangan;
    private double potongan;
    private Uri gambar;
    private String satuan;
    private String key;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public double getPotongan() {
        return potongan;
    }

    public void setPotongan(double potongan) {
        this.potongan = potongan;
    }

    public Uri getGambar() {
        return gambar;
    }

    public void setGambar(Uri gambar) {
        this.gambar = gambar;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public ProductModel(){}

    public ProductModel(
            String name,
            double harga,
            String keterangan,
            double potongan,
            Uri gambar,
            String satuan
        ){
        this.name = name;
        this.harga = harga;
        this.keterangan = keterangan;
        this.potongan = potongan;
        this.gambar = gambar;
        this.satuan = satuan;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
